# Sharp_Memory_LCD-MicroPython
Driver to program Sharp's Memory LCD with MicroPython, on a Pyduino
