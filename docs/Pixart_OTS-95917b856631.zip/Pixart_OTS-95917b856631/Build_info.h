/* mbed Microcontroller Library
 * Copyright (c) 2018 ARM Limited
 * SPDX-License-Identifier: Apache-2.0
 */

/* Optical Track Sensor, OTS, library by PixArt Imaging Inc.
 * Support: PAT9125, PAT9126, PAT9130, PAA5101
 * Primary Engineer: Hill Chen (PixArt USA)
 *
 * License: Apache-2.0; http://www.apache.org/licenses/LICENSE-2.0
 */
 
/* Library Revision History
 * V1.0: March 6, 2019
 * First release. Supports PAT9125, PAT9126, PAT9130, PAA5101. Future to support PAT9150.
 * V1.1:
 * Add support to 5101 LD/LED switching.
 * Add support to PAT9150.
 * Fixed bug on loading initialization setting.
 * Optimized register read timing.
 */

#pragma once

#define DEBUG
//#define USE_CALLBACK

#define FW_VERSION  "v1.1"
#define PRODUCT     "Optical Track Sensor (OTS)"
