/* PixArt Optical Finger Navigation, OFN, sensor driver.
 * By PixArt Imaging Inc.
 * Primary Engineer: Hill Chen (PixArt USA)
 *
 * License: Apache-2.0; http://www.apache.org/licenses/LICENSE-2.0
 */

#pragma once
#include "Pixart_ComPort.h"

struct Pixart_OTS_OtsData
{
    int16_t x;
    int16_t y;
};

class Pixart_OTS_GrabData
{
public:
    virtual Pixart_OTS_OtsData grab(Pixart_ComPort &com_port) = 0;
};

class Pixart_OTS_GrabData_12bitXy: public Pixart_OTS_GrabData
{
public:
    virtual Pixart_OTS_OtsData grab(Pixart_ComPort &com_port);
};

class Pixart_OTS_GrabData_16bitXy: public Pixart_OTS_GrabData
{
public:
    virtual Pixart_OTS_OtsData grab(Pixart_ComPort &com_port);
};

class Pixart_OTS_GrabData_16bitXOnly: public Pixart_OTS_GrabData
{
public:
    virtual Pixart_OTS_OtsData grab(Pixart_ComPort &com_port);
};
